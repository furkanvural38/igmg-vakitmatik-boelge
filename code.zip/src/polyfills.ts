// src/polyfills.ts (ganz am Anfang importieren)
// src/polyfills.ts (vor allem anderen)
// src/polyfills.ts
import 'core-js/stable';
import 'whatwg-fetch';
import 'core-js/features/promise/all-settled';
import 'regenerator-runtime/runtime';
import 'abortcontroller-polyfill/dist/abortcontroller-polyfill-only';
